这里是产品服务
<template>
    <div app-product></div>
</template>
<script>
export default {
    data(){
        return{}
    }
}
</script>
<style>
    
</style>