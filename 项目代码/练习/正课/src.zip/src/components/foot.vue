<template>

    <div class="app-foot">
        <hr class="wire">
        <div class="foot row">
            <pre  class="footleft col-lg-6  d-lg-block d-none">
    声明：本站所有资源仅用于学习及研究使用，切勿用于商业用途，如产生法律纠纷本站概不责！
          资源除标明原创外均来自网络转载，版权归原作者所有，如侵犯到您权益请了联系本站删除！
            </pre>
             <div  class="footright col-lg-6 col-sm-12 pt-3">
        CopyRight © 资源e站（Zye.cc）All Rights Reserved.|粤ICP
         备11000616号|联系我们|E站统计|本次页面加载耗时：0.781s
         
            </div>
        </div>
    </div>

</template>
<script>
export default {
    
}
</script>
<style>
.wire{
    width:100%;
    height:2px;
    background-color:orange;
}
.foot{
    font-size:7px;
   
}
.footleft{
    border:1px soli d#2C3747;
    background: #2C3747;
    padding-top: 10px;
  color:#fff;
}

</style>