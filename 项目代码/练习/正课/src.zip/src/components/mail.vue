
<template>
    <div class="app-mail">
        <div class="mail_hea">
            <img src="" alt="">
        </div>
  
    </div>
</template>
<script>
export default {
    data(){
        return{}
    }
}
</script>
<style>
.app-mail{
     height:100%;
    width:100%;
    position: absolute;
    top:0;
 z-index:1;
}
.mail_hea{
    background:#364d68;
    width: 100%;
    height:100px;
    
}
</style>
    
